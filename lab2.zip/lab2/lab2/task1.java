                                                                                                                                                                                                                                                    //Lab 02 Task -1

import java.util.Scanner;
public class task1{
public static void main(String[] args){
Scanner src=new Scanner(System.in);
char[] const_arr={'r','a','f','i','s','h','a','i','k','h'};
System.out.print("Enter any character: ");
char var=src.next().charAt(0);
if(var==const_arr[0] || var==const_arr[1] || var==const_arr[2] || var==const_arr[3] || var==const_arr[4] 
|| var==const_arr[5] || var==const_arr[6] || var==const_arr[7] || var==const_arr[8] || var==const_arr[9] ){
System.out.println("Character "+var+" is present!");
}
else{
System.out.println("Character "+var+" is not present!");
}
}
}
