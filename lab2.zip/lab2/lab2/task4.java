//Lab 02 Task -4

import java.util.Scanner;
public class task4{
public static void main(String[] args){
Scanner src=new Scanner(System.in);
String[] name={"rafi","ahmed","shaikh"};
String check;
System.out.print("Enter the Name: ");
check=src.nextLine();
for(int I=0; I<name.length; I++){
if(name[I].equalsIgnoreCase(check)){
System.out.print("rafi/Rafi Found!");
break;
}
else{
System.out.println("Name rafi/Rafi not Found!");
}
}
}
}
