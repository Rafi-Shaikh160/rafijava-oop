class cat extends Animal{
	
	
	
void makesound(){
	
	System.out.println("meeeeeeooooow");
	
	
	
}


}