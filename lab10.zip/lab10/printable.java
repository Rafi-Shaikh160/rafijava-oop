interface printable{

public void print();


}