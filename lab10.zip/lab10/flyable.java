interface flyable{




}