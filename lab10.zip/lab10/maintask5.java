public class maintask5{
    public static void main(String[] args) {
        Employee fullTimeEmp = new FullTimeEmployee("RAFI", 101, 5000);
        Employee partTimeEmp = new PartTimeEmployee("hanan", 102, 20, 80);

        System.out.println(fullTimeEmp.name + "'s Salary: rupee" + fullTimeEmp.calculateSalary());

        ((TaxPayer) fullTimeEmp).payTax();

        System.out.println(partTimeEmp.name + "'s Salary: rupee" + partTimeEmp.calculateSalary());
        ((TaxPayer) partTimeEmp).payTax();
    }
}
