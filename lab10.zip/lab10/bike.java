class bike implements vehcile{


public void start(){
	
	System.out.println("sluf start .....");
	
}
 public void stop(){
		System.out.println("sluf stop .....");
	
	
	
	
	
}



}