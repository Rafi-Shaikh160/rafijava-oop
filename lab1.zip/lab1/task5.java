//Lab 01 --->Task -5

import java.util.Scanner;
public class task5{

public static void main(String args[]){
Scanner src=new Scanner(System.in);
System.out.print("\n\t*\n*\t*\n*\t*\n*");

}}