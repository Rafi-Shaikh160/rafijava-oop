//Lab 01 --->Task -1

 public class task1{
public static void main(String[] args){

System.out.println("///////////////////////\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\");
System.out.println("==\t\tStudent Points\t\t==");
System.out.println("\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\//////////////////////////");
System.out.println("Name    \t\tLab\tBonus\tTotal");
System.out.println("----    \t\t---\t-----\t-----");
System.out.println("rafi     \t\t43\t7\t50");
System.out.println("ahmed \t\t50\t8\t58");
System.out.println("shaikh Sue\t\t39\t10\t49");

} 
}