//Lab 01 --->Task -3

import java.util.Scanner;
public class task3{


public static void main(String args[]){
Scanner src=new Scanner(System.in);
String name="RAfi Shaikh";
short age=20;
double gpa=3.14;
char gender='M';
boolean foreigner=false;
int ID=160;

System.out.println("Name: "+name);
System.out.println("Age: "+age);
System.out.println("GPA: "+gpa);
System.out.println("Gender: "+gender);
System.out.println("foreigner: "+foreigner);
System.out.println("Student ID: "+ID);

}
}