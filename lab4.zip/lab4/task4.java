class task4{

    String name;

     int yearOfJoining;

     String address;

    task4(String name, int yearOfJoining, String address) {

        this.name = name;

        this.yearOfJoining = yearOfJoining;

        this.address = address;
    }
    public void displayInfo() {
        System.out.println(name+" "+yearOfJoining+" "+address+" ");
    }


    public static void main(String[] args) {

        task4 emp1 = new task4("Robert", 1994, "WallsStreat");

        task4 emp2 = new task4("Sam", 2000, "WallsStreat");

        task4 emp3 = new task4("John", 1999, "WallsStreat");

        System.out.println("Name yearOfJoining address");



    emp1.displayInfo();
    emp2.displayInfo();
      emp3.displayInfo();

    }
   

}



