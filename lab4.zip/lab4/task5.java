
class task5{

    int id;
    String name;
    double[] grades;

    task5(int id,String name,double[] grades){

        this.id=id;
        this.name=name;
        this.grades=grades;
    }
    
     void display_average_grade(){

        double sum=0;
        for(double num:grades){

            sum+=num;
        }
        double avg=sum/grades.length;
        System.out.println("average gardes of "+ name +" (ID :"+ id +" ) is: "+ avg);
    }
   double[] calcPercentage() {
        double[] percentages = new double[grades.length];
        for (int i = 0; i < grades.length; i++) {
            percentages[i] = (grades[i] / 200) * 100;
        }
        return percentages;
    }
   public String concat_ID_Name(){
    return id+"_"+name;
   
     }
      void displayStudentInfo() {
         System.out.println("\nStudent Details:");
        System.out.println("ID: " + id);
        System.out.println("Name: " + name);
display_average_grade();
double[] percentages = calcPercentage();
        System.out.print("Percentages: ");
        for (double percent : percentages) {
            System.out.print(percent + "% ");
        }
        System.out.println();
        System.out.println("Concatenated ID & Name: " + concat_ID_Name());

      }
   public static void main(String[] args){

   double[] grades1 = {190, 190, 175, 185, 195};
 double[] grades2 = {160, 170, 165, 180, 180};
    task5 obj1=new task5(220,"RAfishaikh",grades1);
    task5 obj2=new task5(221,"haris",grades2);

obj1.displayStudentInfo();
        obj2.displayStudentInfo();

   }
}

