class book{
String tittle;
String author;
boolean isavailable=false;

book(String tittle,String author){
	this.tittle=tittle;
	this.author=author;
}
void borrowbooks(){
	if(isavailable){
	isavailable=false;
    System.out.println("book successfully borrowed");			
	}
	else{
		System.out.println("book is already borrowed");	
	}	
}
void returnbook(){
	
	if(isavailable){	
		
	}
	else{
		
		isavailable=true;
	}
	
}	
	void displaybooks(){
		
    System.out.println("Book Tittle " +tittle);
    System.out.println("Book Author " +author);
    System.out.println("book available check" +isavailable);

		
	}
		
public static void main(String [] args){
book b1 =new book("modern physics",  "dr j.robert oppenheimer");
b1.displaybooks();
b1.borrowbooks();
b1.displaybooks();
b1.borrowbooks();
b1.returnbook();
b1.displaybooks();

}
}