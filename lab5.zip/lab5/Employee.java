class Employee{

String name;
String empid;
int salary;
Employee(String name,String empid,int salary){
this.name=name;
this.empid=empid;
this.salary=salary;

}
void increasesalary(int amount){
	System.out.println(name+"your salary increased"+amount);
	 salary=salary+amount;
	
}
void culculateannualsalry(){
	System.out.println("your annual salary is:"+(salary*12));
	
}
void displayemployeesalarydetails(){
	
	System.out.println("Employee name: "+name);
	System.out.println("Employee id :"+empid);
	System.out.println("your salary is :"+salary);
	
}
public static void main(String [] args){
	Employee e1 =new Employee("RAFI SHAIKH","f24-ARI-160",10000);
	e1.displayemployeesalarydetails();
    e1.culculateannualsalry();
	e1.increasesalary(25000);
	e1.displayemployeesalarydetails();
	e1.culculateannualsalry();	
}
}