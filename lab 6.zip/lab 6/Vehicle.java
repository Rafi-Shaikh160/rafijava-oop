class Vehicle{
	String brand;
	double speed;

	Vehicle(String brand, double speed){
		this.brand=brand;
		this.speed=speed;
	}

	void showDetails(){
		
	}
}