class main{
	public static void main(String[] args){
        // 1st Task Animal




        dog d = new dog();
        d.makeSound();


        // 2nd Task Person


		GradStudent s = new GradStudent("RAfi",21,"f24ari160","artificial intelligence");
		s.displayInfo();





		//3rd Task Vehicle



		Car v = new Car("nissan",70, 7);
		v.showDetails();
		Bike b = new Bike("crlf",70, " black");
		b.showDetails();


       // 4th Task Shape



		Shape shape;
		shape  = new Circle();
		shape.draw();
        shape  = new Rectangle();
        shape.draw();


	}
}