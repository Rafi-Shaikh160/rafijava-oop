class animal{
	String name;
	int age;

	void makeSound(){
		System.out.println("animal make sound");
	}
}