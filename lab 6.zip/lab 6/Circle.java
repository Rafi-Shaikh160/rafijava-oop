class Circle extends Shape{

 void draw(){
 	System.out.println("Draw a circle");
 }
}