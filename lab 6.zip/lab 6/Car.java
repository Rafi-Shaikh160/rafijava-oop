class Car extends Vehicle{
	int numDoors;

	Car(String brand, double speed, int numDoors){




		super(brand,speed);
     this.numDoors=numDoors;
	}
	void showDetails(){



	System.out.println(" Car Details ");

    System.out.println("Brand: "+super.brand+"Speed: "+super.speed+"Numdoors: "+numDoors);

	}
}