class Rectangle extends Shape{

	void draw(){
		System.out.println("Draw a Rectangle");
	}
}