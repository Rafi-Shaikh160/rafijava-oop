class student extends person{


	String studentiD;

	student(String name, int age, String studentiD){
		super(name,age);
		this.studentiD=studentiD;
	}
	void displayInfo(){
	
	}

}