class dog extends animal{
  
  void makeSound(){
   System.out.println("dog is barking");
  }
	
}