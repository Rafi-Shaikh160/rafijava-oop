class Shape{
	
	void draw(){
		System.out.print("Draw a shape ");
	}
}