class HDFC extends Bank {

    public double getInterestRate() {
        return 6.8;
    }
}