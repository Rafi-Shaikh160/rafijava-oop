class ICICI extends Bank {

    public double getInterestRate() {
        return 8.2;
    }
}
