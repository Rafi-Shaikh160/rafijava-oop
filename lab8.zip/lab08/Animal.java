class Animal {

    public void makeSound() {
        
        System.out.println("animal makes a sound.");
    }
}

