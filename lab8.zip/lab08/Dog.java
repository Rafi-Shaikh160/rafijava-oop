class Dog extends Animal {

    public void makeSound() {

        System.out.println("Dog sounds barks");
    }
}