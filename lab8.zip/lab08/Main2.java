 class Main2 {

    public static void main(String[] args) {

        Student student = new Student();

        student.setName("RAFI SHAIKH");

        student.setRollNumber(160);


        student.setGrade('A');

        student.displayDetails();
    }
}
