class ReverseString {



    public String reverseString(String str) {

        String reversed = "";

        for (int i = str.length() - 1; i >= 0; i--) {

            reversed += str.charAt(i);

        }
        return reversed;

    }


    public static void main(String[] args) {

        ReverseString rs = new ReverseString();

        System.out.println(rs.reverseString("RAFI"));
    }
}
