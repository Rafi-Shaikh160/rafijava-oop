import java.util.Scanner;

	class task7{

		public static void main(String[] args){

			Scanner input = new Scanner(System.in);

			String check= input.nextLine();

			System.out.print(check.replace(" ",""));

		}
	}