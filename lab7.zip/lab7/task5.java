import java.util.Scanner;

	class task5{

		public static void main(String[] args){

			Scanner input = new Scanner(System.in);

			String check= input.nextLine();

			if (check.endsWith("world")){

				System.out.print("yes String ends with World");

			}
			else{
				System.out.print(" no String does not ends with World");
			}
		}
	}