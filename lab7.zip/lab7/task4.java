import java.util.Scanner;

	class task4{

		public static void main(String[] args){

			Scanner input = new Scanner(System.in);

			String check= input.nextLine();

			if (check.startsWith("hello")){

				System.out.print("yes String Starts with hello");

			}
			else{

				System.out.print("no String is  not start with hello");
			}
		}
	}