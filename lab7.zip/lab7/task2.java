import java.util.Scanner;

	class task2{

		public static void main(String[] args){

			Scanner input = new Scanner(System.in);

			System.out.print("Find the letter A if available");

			String str = input.nextLine();

			int index = str.indexOf("a");

			System.out.println("index of first a: " + index);
		}
	
}