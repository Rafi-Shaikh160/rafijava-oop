import java.util.Scanner;

class task1{


	public static void main(String[] args){

	Scanner input = new Scanner(System.in);

     System.out.print("please enter any  string: ");

     String check = input.nextLine();
     if (check.isEmpty()){
     	System.out.println("string is empty");
     	}
     	else{
     		System.out.println("string is not empty");
     	}
     }
	}